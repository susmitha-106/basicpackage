basicpackage


The basicpackage is a simple testing example to understand the basics of developing your first Python package.

<!-- Install & Usage
You can install basicpackageas follows:

pip install --index-url https://test.pypi.org/simple/ --no-deps basicpackage -->



Try to have fun with basicpackage:

from multiply.by_three import multiply_by_three
from divide.by_three import divide_by_three

multiply_by_three(9)
divide_by_three(21)

